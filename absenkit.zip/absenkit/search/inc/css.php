<link rel="shortcut icon" href="../assets/img/fav-icon.ico" type="image/x-icon">

<link rel="stylesheet" href="../assets/css/separate/pages/others.min.css">
<link rel="stylesheet" href="../assets/css/separate/pages/mail.min.css">
<link rel="stylesheet" href="../assets/css/separate/vendor/bootstrap-select/bootstrap-select.min.css">
<link rel="stylesheet" href="../assets/css/separate/vendor/bootstrap-daterangepicker.min.css">
<link rel="stylesheet" href="../assets/css/separate/vendor/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="../assets/css/separate/vendor/sweet-alert-animations.min.css">

<link rel="stylesheet" href="../assets/css/lib/summernote/summernote.css">
<link rel="stylesheet" href="../assets/css/lib/bootstrap-sweetalert/sweetalert.css">
<link rel="stylesheet" href="../assets/css/lib/clockpicker/bootstrap-clockpicker.min.css">
<link rel="stylesheet" href="../assets/css/lib/bootstrap-table/bootstrap-table.min.css">
<link rel="stylesheet" href="../assets/css/lib/font-awesome/font-awesome.min.css">
<link rel="stylesheet" href="../assets/css/lib/bootstrap/bootstrap.min.css">
<link rel="stylesheet" href="../assets/css/main.css">
	
</head>