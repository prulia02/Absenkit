<?php 
//redirect ke halaman error
header('location:page.php?halaman-admin');
?>
